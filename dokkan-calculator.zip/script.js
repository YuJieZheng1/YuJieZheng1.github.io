function calculateATK() {
  const base = parseInt(document.getElementById("atkStat").value) || 0;
  const leader = (parseInt(document.getElementById("atkLeader").value) || 0) / 100;
  const links = (parseInt(document.getElementById("atkLinks").value) || 0) / 100;

  const result = Math.floor(base * (1 + leader + links));
  document.getElementById("atkResult").textContent = `Result: ${result.toLocaleString()}`;
}

function calculateDEF() {
  const base = parseInt(document.getElementById("defStat").value) || 0;
  const leader = (parseInt(document.getElementById("defLeader").value) || 0) / 100;
  const support = (parseInt(document.getElementById("defSupportMemory").value) || 0) / 100;
  const links = (parseInt(document.getElementById("defLinks").value) || 0) / 100;
  const stacking = (parseInt(document.getElementById("defStacking").value) || 0) / 100;

  const result = Math.floor(base * (1 + leader + support + links + stacking));
  document.getElementById("defResult").textContent = `Result: ${result.toLocaleString()}`;
}
